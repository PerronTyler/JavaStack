package com.tyler.yoga;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YogaApplicationTests {

	@Test
	void contextLoads() {
	}

}
